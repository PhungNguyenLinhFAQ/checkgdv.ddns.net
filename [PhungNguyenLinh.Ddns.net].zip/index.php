<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="Trang chủ phungnguyenlinh.ddns.net, chuyên chia sẽ thủ thuật không gian mạng.">
    <meta name="author" content="PhungNguyenLinh">
    <meta name="keywords" content="PhungNguyenLinh">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="shortcut icon" href="//i.imgur.com/LC5mbkf.jpg" type="image/x-icon">
    <title>NGUYENLINH - HOME</title>
    <link rel="stylesheet" href="./thanhdieuft-data/css/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pattaya|Potta One|Rowdies|Braah One|Monomaniac One">
    <script src='./thanhdieuft-data/js/jquery.min.js'></script>
    <meta property="og:title" content="WELCOME TO PHUNGNGUYENLINH - HOME">
    <meta property="og:type" content="website">
    <meta property="og:url" content="//phungnguyenlinh.ddns.net">
    <meta property="og:image" content="//i.imgur.com/G8VxTOK.jpg">
    <meta name="theme-color" content="#000FFF">
  </head>

   <div id="particles-js"></div>

  <div class="Not-CopySource" id="Telegram_@ThanhDieuChannel">

</div>

<section class="animated-background">
    <div id="stars1"></div>
    <div id="stars2"></div>
    <div id="stars3"></div>
  </section>
  <body class="Border" onLoad="onCreate()">
    <div class="LoaderCover">
      <div class="Loader">
        <div class="lds-ripple"><div></div><div></div></div>
      <br/>
        <br/>
          <br/>
            <br/>
              <br/>
                <br/>
                <br/>  
              <br/>
            <br/>
          <br/>
        <br/>
      <br/>
      <h2 class="NameFtNguyenLinh">Loading 🐬</h2>
        </div>
      </div>
    <!-- ===== Navigation Bar ===== -->
<div class="BlurWebs">
      <div class="Topnav">
        <a style="font-family: 'Concert One';" class="Active">HOME</a>
        <a style="font-family: 'Concert One';" href="./download/">DOWNLOAD</a>
        <a style="font-family: 'Concert One'; color:rgb(255, 0, 0);">
          <span id="fps">60.0</span> FPS </a>
      </div>
      </div>
      <br/>
      <p align="center">
        <img class="Blob" src="https://i.imgur.com/G8VxTOK.jpg" width="120" height="120" alt="PhungNguyenLinh">
      </p>
      <h2 class="NameFtNguyenLinh">
        <div id="userName" style="font-family: 'Pattaya';">Phung Nguyen Linh <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Twitter_Verified_Badge.svg/512px-Twitter_Verified_Badge.svg.png" width="17" height="17" alt="Tích Xanh"></div>
    </div>
      </h2>
      <h2 class="TieuSu GioiThieu" style="font-family: 'Potta One';">hi bro<span class="typed-cursor" aria-hidden="true"></span></h2>
      <br/>
      <strong style="color: rgb(255, 238, 0); font-size: 16px; font-family: 'Rowdies';">You Info: <a id="checkip_address">Loading your address....</a>
        <br/>
      </strong>
      <strong style="color: rgb(255, 0, 0); font-size: 16px; font-family: 'Rowdies';">Date Created:</strong>
      <span style="color: rgb(0, 240, 120);
        animation: colorRotate 2.5s linear 0s infinite;
        @keyframes colorRotate {
            from {
              color: #FF0000;
            }
            10% {
              color: #00FFFF;
            }
            50% {
              color: #00FF00;
            }
             100% {
              color: #FFFF00;
            }
          } font-size: 16px; font-family: 'Rowdies';" id="momk"></span>
      <script type="text/javascript" src="./thanhdieuft-data/js/time-activated.js"></script>
      </strong>
      <a id="noisong"></a>
      <br/>
      <br/>
      <div class="card-content">
        <canvas id="canvas" style="width:100%;" width="820" height="250"></canvas>
        <script>
        (function(){var t=820;var a=250;var r=7;var n=10;var e=.65;var f;var o=[];const v=["#33B5E5","#0099CC","#AA66CC","#9933CC","#99CC00","#669900","#FFBB33","#FF8800","#FF4444","#CC0000"];var h=[];var u=[[[0,0,1,1,1,0,0],[0,1,1,0,1,1,0],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[0,1,1,0,1,1,0],[0,0,1,1,1,0,0]],[[0,0,0,1,1,0,0],[0,1,1,1,1,0,0],[0,0,0,1,1,0,0],[0,0,0,1,1,0,0],[0,0,0,1,1,0,0],[0,0,0,1,1,0,0],[0,0,0,1,1,0,0],[0,0,0,1,1,0,0],[0,0,0,1,1,0,0],[1,1,1,1,1,1,1]],[[0,1,1,1,1,1,0],[1,1,0,0,0,1,1],[0,0,0,0,0,1,1],[0,0,0,0,1,1,0],[0,0,0,1,1,0,0],[0,0,1,1,0,0,0],[0,1,1,0,0,0,0],[1,1,0,0,0,0,0],[1,1,0,0,0,1,1],[1,1,1,1,1,1,1]],[[1,1,1,1,1,1,1],[0,0,0,0,0,1,1],[0,0,0,0,1,1,0],[0,0,0,1,1,0,0],[0,0,1,1,1,0,0],[0,0,0,0,1,1,0],[0,0,0,0,0,1,1],[0,0,0,0,0,1,1],[1,1,0,0,0,1,1],[0,1,1,1,1,1,0]],[[0,0,0,0,1,1,0],[0,0,0,1,1,1,0],[0,0,1,1,1,1,0],[0,1,1,0,1,1,0],[1,1,0,0,1,1,0],[1,1,1,1,1,1,1],[0,0,0,0,1,1,0],[0,0,0,0,1,1,0],[0,0,0,0,1,1,0],[0,0,0,1,1,1,1]],[[1,1,1,1,1,1,1],[1,1,0,0,0,0,0],[1,1,0,0,0,0,0],[1,1,1,1,1,1,0],[0,0,0,0,0,1,1],[0,0,0,0,0,1,1],[0,0,0,0,0,1,1],[0,0,0,0,0,1,1],[1,1,0,0,0,1,1],[0,1,1,1,1,1,0]],[[0,0,0,0,1,1,0],[0,0,1,1,0,0,0],[0,1,1,0,0,0,0],[1,1,0,0,0,0,0],[1,1,0,1,1,1,0],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[0,1,1,1,1,1,0]],[[1,1,1,1,1,1,1],[1,1,0,0,0,1,1],[0,0,0,0,1,1,0],[0,0,0,0,1,1,0],[0,0,0,1,1,0,0],[0,0,0,1,1,0,0],[0,0,1,1,0,0,0],[0,0,1,1,0,0,0],[0,0,1,1,0,0,0],[0,0,1,1,0,0,0]],[[0,1,1,1,1,1,0],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[0,1,1,1,1,1,0],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[0,1,1,1,1,1,0]],[[0,1,1,1,1,1,0],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[1,1,0,0,0,1,1],[0,1,1,1,0,1,1],[0,0,0,0,0,1,1],[0,0,0,0,0,1,1],[0,0,0,0,1,1,0],[0,0,0,1,1,0,0],[0,1,1,0,0,0,0]],[[0,0,0,0],[0,0,0,0],[0,1,1,0],[0,1,1,0],[0,0,0,0],[0,0,0,0],[0,1,1,0],[0,1,1,0],[0,0,0,0],[0,0,0,0]]];function l(t){var a=[];f.fillStyle="#005EAC";var r=new Date;var e=70,o=30;var v=r.getHours();var u=Math.floor(v/10);var l=v%10;a.push({num:u});a.push({num:l});a.push({num:10});var c=r.getMinutes();var u=Math.floor(c/10);var l=c%10;a.push({num:u});a.push({num:l});a.push({num:10});var M=r.getSeconds();var u=Math.floor(M/10);var l=M%10;a.push({num:u});a.push({num:l});for(var p=0;p<a.length;p++){a[p].offsetX=e;e=m(e,o,a[p].num,t);if(p<a.length-1){if(a[p].num!=10&&a[p+1].num!=10){e+=n}}}if(h.length==0){h=a}else{for(var C=0;C<h.length;C++){if(h[C].num!=a[C].num){s(a[C]);h[C].num=a[C].num}}}i(t);g();return r}function s(t){var a=t.num;var n=u[a];for(var e=0;e<n.length;e++){for(var f=0;f<n[e].length;f++){if(n[e][f]==1){var h={offsetX:t.offsetX+r+r*2*f,offsetY:30+r+r*2*e,color:v[Math.floor(Math.random()*v.length)],g:1.5+Math.random(),vx:Math.pow(-1,Math.ceil(Math.random()*10))*4+Math.random(),vy:-5};o.push(h)}}}}function i(t){for(var a=0;a<o.length;a++){t.beginPath();t.fillStyle=o[a].color;t.arc(o[a].offsetX,o[a].offsetY,r,0,2*Math.PI);t.fill()}}function g(){var n=0;for(var f=0;f<o.length;f++){var v=o[f];v.offsetX+=v.vx;v.offsetY+=v.vy;v.vy+=v.g;if(v.offsetY>a-r){v.offsetY=a-r;v.vy=-v.vy*e}if(v.offsetX>r&&v.offsetX<t-r){o[n]=o[f];n++}}for(;n<o.length;n++){o.pop()}}function m(t,a,n,e){var f=u[n];for(var o=0;o<f.length;o++){for(var v=0;v<f[o].length;v++){if(f[o][v]==1){e.beginPath();e.arc(t+r+r*2*v,a+r+r*2*o,r,0,2*Math.PI);e.fill()}}}e.beginPath();t+=f[0].length*r*2;return t}var c=document.getElementById("canvas");c.width=t;c.height=a;f=c.getContext("2d");var M=new Date;setInterval(function(){f.clearRect(0,0,f.canvas.width,f.canvas.height);l(f)},50)})();
        </script>
        </div>
        <br/>
      <hr class="New">
      <br/>
      <ul class="icons">
        <br/>
        <div class="MangXaHoiFtNguyenLinh" id="Fb_@WusThanhDieu">
          <u class="NameFtNguyenLinh">- Social Network -</u><br/>
          <br/>
          <a id="Facebook" onClick="Facebook()">
            <div class="Facebook">
              <i class="bi bi-facebook">&nbsp; </i>Facebook ( Click Vào Đây)
            </div>
          </a>
          <br/>
        </div>
        <br/>
        <br/>
        <hr class="New">
        <br/>
        <br/>
    </div>
    <section id="skills">
      <div class="NameFtNguyenLinh" class="container skills">
        <div class="row">
          <Skills class="col-12">
            <u class="NameFtNguyenLinh">- Skill Language -<br/>
            </u>
        </div>
      </div>
      <div class="col-lg-6 col-12">
        <div class="skill-box">
          <div class="skill">
            <div class="skill-name">HTML/CSS</div>
            <div class="skill-bar">
              <div class="skill-per color1" per="76"></div>
            </div>
          </div>
          <div class="skill">
            <div class="skill-name">MySql</div>
            <div class="skill-bar">
              <div class="skill-per color3" per="9"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-12">
        <div class="skill-box">
          <div class="skill">
            <div class="skill-name">Lua</div>
            <div class="skill-bar">
              <div class="skill-per color1" per="68"></div>
            </div>
          </div>
          <div class="skill">
            <div class="skill-name">PHP</div>
            <div class="skill-bar">
              <div class="skill-per color2" per="12"></div>
            </div>
          </div>
        </div>
    </section>
    <br/>
    <br/>
    <br/>
     </div>
     </article>
  </div><br/><br/>
  <hr class="New">
    </div>
    </div>
    </div>
    </div>
    <script text="type/javascript">
      // ADD SOUND NHẠC TẠI ĐÂY
const ThanhDieu_List_Sounds = [
"https://phungnguyenlinh.ddns.net/files/nothingonyou1.mp3",
];
// EDIT TEXT ALERT TẠI ĐÂY
function HomeThanhDieu() {
  Swal.fire({
    title: '𝙉𝙤𝙩𝙞𝙛𝙞𝙘𝙖𝙩𝙞𝙤𝙣 !',
    text: '=>> 𝙒𝙚𝙡𝙘𝙤𝙢𝙚 𝙃𝙪𝙣𝙣𝙞𝙚 𝘽𝙖𝙘𝙠 𝙏𝙤 𝙏𝙝𝙚 𝙃𝙤𝙢𝙚𝙋𝙖𝙜𝙚 🐬 <<=',
    showConfirmButton: false
  });
}
// EDIT LINK TẠI ĐÂY
function Facebook() {
  setTimeout(function() {
    window.open('https://www.facebook.com/Profile.PhungNguyenLinh', '_blank')},
  100);
}
    </script>
    </div>
    <script src="./thanhdieuft-data/js/particles.js"></script>
    <script src="./thanhdieuft-data/js/app.js"></script>
    <script src='./thanhdieuft-data/js/jquery.min.js'></script>
    <script src="./thanhdieuft-data/js/index.js"></script>
  </body>
</html>